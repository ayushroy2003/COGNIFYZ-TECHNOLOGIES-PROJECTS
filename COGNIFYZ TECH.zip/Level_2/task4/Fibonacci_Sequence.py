def fibonacci_sequence(n):
    list_sequence = []
    x , y = 0 , 1
    for _ in range(n):
        list_sequence.append(x)
        x,y = y, x+y
    return list_sequence


n = int(input("Please Enter the number of terms: "))
print(fibonacci_sequence(n))
