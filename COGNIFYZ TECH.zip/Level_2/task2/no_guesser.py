import random

def gernertor_random_no(lowerlimit,upperlimit):
    return random.randint(lowerlimit,upperlimit)

def players_guess():
    try:
        return int(input("please enter your guess"))
    except ValueError:
        print("invalid input :  Enter only number")
        return players_guess
    
def providing_feedback_to_Players(guess,target):
    if guess < target :
        print("Too Low , Try Again")
    elif guess > target :
        print("Too High , Try Again ")
    else :
        print(" Congrats You guessed the Right Number:", target)
        return True
    return False

def guess_number(target,attempts=0):
    guess = players_guess()
    attempts += 1
    if providing_feedback_to_Players(guess,target):
        print("you guessed the correct no and total attempts:",attempts)
    else:
        guess_number(target,attempts)


def no_guesser():
    lowerlimit = 10
    upperlimit = 20

    random_no = gernertor_random_no(lowerlimit, upperlimit)

    print("Welcome to no guesser. Guess a no between",lowerlimit, "and",upperlimit)
    guess_number(random_no)


no_guesser()

    
