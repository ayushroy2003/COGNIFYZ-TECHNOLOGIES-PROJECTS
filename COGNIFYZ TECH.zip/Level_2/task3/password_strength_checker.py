import re 

def password_strength_checker(password):
    length_parameter = len(password) >= 8
    lowercase_parameter = re.search(r'[a-z]',password) is not None
    uppercase_parameter = re.search(r'[A-Z]', password) is not None
    digit_parameter = re.search(r'[0-9]', password) is not None
    special_character_parameter = re.search(r'[\W_]', password) is not None


    point = sum([length_parameter, lowercase_parameter, uppercase_parameter, digit_parameter, special_character_parameter])

    if point == 5 :
        strength = "very strong"
    elif point == 4 :
        strength = "strong"
    elif point == 3 :
        strength = "medium"
    elif point == 2 :
        strength = "weak"
    else :
        strength = "very weak"

    return strength


password = input("Enter your password - ")
print("password strength - ", password_strength_checker(password))


