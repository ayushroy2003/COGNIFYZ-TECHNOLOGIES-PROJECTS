from collections import Counter 
import re 

def counting_words(txt_file):
    try:
        with open(txt_file, 'r') as file :
            text = file.read().lower()
            words = re.findall(r'\b\w+\b', text)
            words_count = Counter(words)
            
            for word in sorted(words_count):
                print(word,": ",words_count[word])

    except FileNotFoundError:
        print("The file does not exist")
    except Exception as e:
        print("an error is occured ",e)

counting_words('sample_text.txt')
