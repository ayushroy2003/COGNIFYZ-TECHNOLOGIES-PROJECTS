import random

def guessing_game(number_to_be_guess) :
    try:
        player_guess = int(input("Hey What is your guess?"))
        if player_guess < number_to_be_guess:
            print("Too Low! Enter agaim")
            guessing_game(number_to_be_guess)
        elif player_guess > number_to_be_guess:
            print("Too High! Enter again ")
            guessing_game(number_to_be_guess)
        else:
            print("Congrats! You guessed The correct no.",number_to_be_guess)

    except ValueError:
        print("Entered Wrong Input! please enter a valid number")
        guessing_game(number_to_be_guess)


print("Welcome to the guessing game! I've picked a number between 1 and 100. Can you guess what it is?")

number_to_be_guess = random.randint(1,100)
guessing_game(number_to_be_guess)  



        
       


