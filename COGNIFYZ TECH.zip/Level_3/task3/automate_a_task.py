import pandas as pd
import numpy as np

def load_data(filepath):
    """Read data from a CSV file."""
    return pd.read_csv(filepath)

def handle_missing_values(dataframe):
    """Handle missing values in the DataFrame."""
    
    numeric_columns = dataframe.select_dtypes(include=[np.number]).columns
    dataframe[numeric_columns] = dataframe[numeric_columns].fillna(dataframe[numeric_columns].mean())
    return dataframe

def correct_data_formats(dataframe):
    """Ensure columns have correct data types."""
    
    if 'date_of_joining' in dataframe.columns:
        dataframe['date_of_joining'] = pd.to_datetime(dataframe['date_of_joining'], errors='coerce')
    return dataframe

def remove_duplicates(dataframe):
    """Remove duplicate entries from the DataFrame."""
    dataframe.drop_duplicates(inplace=True)
    return dataframe

def handle_outliers(dataframe):
    """Identify and handle outliers in the DataFrame."""
    
    for column in dataframe.select_dtypes(include=[np.number]).columns:
        mean_val = dataframe[column].mean()
        std_val = dataframe[column].std()
        dataframe = dataframe[(dataframe[column] >= mean_val - 3 * std_val) & (dataframe[column] <= mean_val + 3 * std_val)]
    return dataframe

def clean_data(filepath, output_path):
    """Clean data from the input file and save the cleaned data to the output file."""
    dataframe = load_data(filepath)
    dataframe = handle_missing_values(dataframe)
    dataframe = correct_data_formats(dataframe)
    dataframe = remove_duplicates(dataframe)
    dataframe = handle_outliers(dataframe)
    dataframe.to_csv(output_path, index=False)
    print(f"Cleaned data saved to {output_path}")

# Example
input_file = 'sample_data.csv'  
output_file = 'cleaned_data.csv'  
clean_data(input_file, output_file)
