def string_reverse(test_str):
    return test_str[::-1]

test_str = "hello"
print(string_reverse(test_str))



