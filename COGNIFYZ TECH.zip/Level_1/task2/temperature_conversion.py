def conversion_temperature():

    temperature = float(input("Enter the temperature Value:"))

    unit = input("Enter the unit of measurement(C for Celsius, F for Fahrenheit) ").strip().upper()

    if unit == "C":
        converted_temp = (temperature*9/5)+32
        print(temperature,"°C is equal to",converted_temp,"°F")

    elif unit =="F":
        converted_temp = (temperature-32)*5/9
        print(temperature,"°F is equal to ",converted_temp,"°C")

    else:
        print("Invalid unit of meausrement. Enter C for Celisus and F for Fahrenheit")

conversion_temperature()
