def add(x,y):
    return x+y

def subtract(x,y):
    return x-y

def multiply(x,y):
    return x*y

def divide(x,y):
    if y== 0:
        return "Error: can not divide by zero - Division by zero"
    else:
        return x/y

def remainder(x,y):
    if y ==0:
        return "Error :module by zero"

def calculate(x,y,operator):
    if operator =='+':
        return add(x,y)
    elif operator == '-':
        return subtract(x,y)
    elif operator == '*':
        return multiply(x,y)
    elif operator =='/':
        return divide(x,y)
    elif operator =='%':
        return remainder(x,y)
    else:
        return "GIVEN OPERATOR IS INVALID"
    
if __name__ == "__main__":

    number1 = float(input("Enter the first no. :"))
    number2 = float(input("enter the second no. :"))
    op = input("Emter an operator(+,-,*,/,%)")

    calculated_results = calculate(number1,number2,op)

    print("Result:",calculated_results)
    