import re 
def is_it_email_valid(email):
    email_pattern = re.compile(
        r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
        )
    if email_pattern.match(email):
        return True
    else:
        return False
    

testing_email = [
    "royayush98765z@gmail.com",
    "simran@gmail.com",
    "sweta@gmail.com",
    "nirita@gmail.com",
    "rajesh@gmail.com",
    "ayushgmai.com"
]

for email in testing_email:
    print(email,":",is_it_email_valid(email))