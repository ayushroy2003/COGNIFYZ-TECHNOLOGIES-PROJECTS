def palindrome_checker(text: str) -> bool:
    text = text.lower()

    cleaned_text = ''
    for char in text:
        if char.isalnum():
            cleaned_text += char

    return cleaned_text == cleaned_text[::-1]

print(palindrome_checker("racecar"))

